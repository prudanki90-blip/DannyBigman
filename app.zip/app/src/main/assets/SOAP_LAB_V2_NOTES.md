# SOAP LAB v2.0 replacement package

## Included
- Expanded `soap_lab_database.json` with 52 oil/fat/wax reference records, fatty-acid ranges and representative SAP estimates.
- `soap_lab_additives_database.json` with 51 additive, filler, fragrance, salt, chelator, beverage, thickener, colorant, surfactant and preservative records.
- Updated `index.html` with replacement Formula Lab, product-type planning, oil profile estimates, hybrid consistency study, additive screening warnings, complete local recipe save/export, ingredient search and oil-blend experiment optimizer.
- Existing Android entry point, branding, world soap library, chemistry, notebook, settings and costing UI retained.

## Important limitations
- SAP values and fatty-acid ranges are representative educational estimates, not independently source-audited values for any supplier lot. The app intentionally does not output operational NaOH/KOH weights. Lye purity and superfat fields are stored as study inputs, not used to calculate a caustic dose.
- Additive percentages are screening prompts, not universal safe-use limits. For fragrance and essential oils, the exact supplier/IFRA limit and intended product category take priority. Preservatives require supplier-specific conditions and stability/challenge testing.
- Liquid consistency predictions are qualitative heuristics, not measured viscosity. Real soap and surfactant systems depend on complete formulation, concentration, temperature, pH, electrolyte level, and process history.
- Shampoo and shower gel commonly require a purpose-designed surfactant system and preservation; they are not interchangeable with true soap.
- The optimizer searches oil ratios only among oils with positive mass in Formula Lab. Scores are heuristic comparisons, not guarantees of performance or skin safety.

## Validation performed
- Parsed both database JSON files.
- Checked every additive record for a unique ID, category, description, screening range and warning.
- Checked every oil record for a unique ID and numeric representative SAP estimate.
- Ran JavaScript syntax validation with Node.js.
- Checked that all navigation pages have a render route and all required assets remain in the package.

## Local storage
Recipes, formulation inputs, experiment targets, ingredient prices, notes and settings remain local to the device/browser storage. Use the existing export features for backup.
